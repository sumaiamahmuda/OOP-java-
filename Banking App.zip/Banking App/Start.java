import java.lang.*;
import java.util.*;
import java.io.*;
import classes.*;
import interfaces.*;
import file.*;

public class Start
{
	public static void main(String args[])
	{
		System.out.println();
		System.out.println("Welcome to Banking App!");
		
		Scanner sc = new Scanner(System.in);
		
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader bfr = new BufferedReader(isr);
		
		fileClass frwd = new fileClass();
		
		Bank b = new Bank();
		
		boolean choice = true;
		
		while(choice)
		{
			
			System.out.println();
			
			System.out.println("Enter required option to continue....");
			System.out.println("1. Employee Management");
			System.out.println("2. Customer Management");
			System.out.println("3. Account Transactions");
			System.out.println("4. Exit");
			
			System.out.print("Option_ ");
			int option = sc.nextInt();
			System.out.println();
			
			switch(option)
			{
				case 1:
					System.out.println("Employee Management----");
					System.out.println("1. Insert New Employee");
					System.out.println("2. Remove Existing Employee");
					System.out.println("3. Show All Employees");
					System.out.println("4. Go Back");
					
					System.out.print("Option_ ");
					int eMoption = sc.nextInt();
					System.out.println();
					switch(eMoption)
					{
						case 1:
							System.out.println("Insert New Employee Selected ");
							
							Employee e = new Employee();
							
							System.out.print("Enter Employee Name: ");
							String name1 = sc.next();
							e.setName(name1);
							
							System.out.print("Enter Employee ID: ");
							String empId1 = sc.next();
							e.setEmpId(empId1);
							
							System.out.print("Enter Employee Salary: ");
							double salary1 = sc.nextDouble();
							e.setSalary(salary1);
							
							
							b.insertEmployee(e);
							System.out.println();
							break;
							
						case 2:
							System.out.println("Remove Existing Employee Selected");
							
							System.out.print("Enter Employee ID: ");
							String empId2 = sc.next();
							
							b.removeEmployee(b.getEmployee(empId2));
							System.out.println();
							break;
						
						
						
						case 3:
							System.out.println("Show All Employees Selected");
							System.out.println("List of All Employees :");
							
							b.showAllEmployees();
							System.out.println();
							break;
						
						case 4:
							System.out.println("Going Back...");
							System.out.println();
							break;
						
						default:
						
							System.out.println("You Have Selected an Invalid Option! \nPlease Try Again!");
							System.out.println();
							break;
					}
					
					break;
				
				case 2:
	
					System.out.println("Customer Management----");
					
					System.out.println("1. Insert New Customer");
					System.out.println("2. Remove Existing Customer");
					System.out.println("3. Show All Customers");
					System.out.println("4. Go Back");
					
					System.out.print("Option_");
					int cMoption = sc.nextInt();
					System.out.println();
					switch(cMoption)
					{
						case 1:
							System.out.println("Insert New Customer Selected ");
							
							Customer cust1 = new Customer();						
							Account a = new Account();
							
							System.out.println("Customer Informations >");
							System.out.print("Enter Customer Name: ");
							String name1 = sc.next();							
							cust1.setName(name1);
							System.out.print("Enter Customer NID: ");
							int nid1 = sc.nextInt();
							cust1.setNid(nid1);
							
							b.insertCustomer(cust1);
							
							System.out.println();
							System.out.println("Account Informations >");
							System.out.print("Enter Account Number : ");
							int an1 = sc.nextInt();
							a.setAccountNumber(an1);
							System.out.print("Enter Initial Amount : ");
							double balance1 = sc.nextDouble();
							a.setBalance(balance1);																				
							b.getCustomer(nid1).insertAccount(a);
							
							System.out.println();
							break;
							
						case 2:
							System.out.println("Remove Existing Customer Selected");
							
							System.out.print("Enter Customer NID: ");
							int nid2 = sc.nextInt();	
							
							Customer cust2 = b.getCustomer(nid2);
							
							b.removeCustomer(cust2);
							System.out.println();
							break;
				
						case 3:
							System.out.println("Show All Customers Selected ");
							System.out.println("List of All Customers :");
							
							b.showAllCustomers();
							
							System.out.println();
							break;
						
						case 4:							
							System.out.println("Going Back...");
							System.out.println();
							break;
						
						default:
					
							System.out.println("You Have Selected an Invalid Option! \nPlease Try Again!");
							System.out.println();
							break;
					}

					
					break;
					
									
				case 3:
			
					System.out.println("Account Transactions----");
					System.out.println("1. Deposit Money");
					System.out.println("2. Withdraw Money");
					System.out.println("3. Go Back");
					
					System.out.print("Option_ ");
					int aToption = sc.nextInt();
					System.out.println();
					switch(aToption)
					{
						case 1:
						
							System.out.println("Deposit Money Selected");
												
							System.out.print("Enter Customer Nid: ");
							int nid1 = sc.nextInt();
							System.out.print("Enter Account Number: ");
							int an1 = sc.nextInt();
							System.out.print("Enter Amount: ");
							double amount1 = sc.nextDouble();
							
							if(amount1>0)
							{								
								Customer cc = b.getCustomer(nid1);
								Account aa = cc.getAccount(an1);
								aa.deposit(amount1);				
								frwd.writeInFile(amount1 +" Deposited in Account Number: "+an1+"\n");
							}
							
							System.out.println();
							break;
							
						case 2:
							System.out.println("Withdraw Money Selected");
							
							System.out.print("Enter Customer Nid: ");
							int nid2 = sc.nextInt();
							System.out.print("Enter Account Number: ");
							int an2 = sc.nextInt();
							System.out.print("Enter Amount: ");
							double amount2 = sc.nextDouble();
							
								
							Customer cc = b.getCustomer(nid2);
							Account aa = cc.getAccount(an2);
							aa.withdraw(amount2);
								
							frwd.writeInFile(amount2 +" Withdrawn from Account Number: "+an2+"\n");
								
							
							System.out.println();
							break;
							
						
						case 3:
						
							System.out.println("Going back....");
							System.out.println();
							break;
							
						default:
						
							
							System.out.println("You Have Selected an Invalid Option! \nPlease Try Again!");
							System.out.println();
							break;
					}
					
					break;
					
				case 4:
					
					System.out.println("Program Exited Successfully");
					choice = false;
					break;
					
				default:
				
					System.out.println("You Have Selected an Invalid Option! \nPlease Try Again!");
					break;
			}
		}
	}
}