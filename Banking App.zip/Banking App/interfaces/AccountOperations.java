package interfaces;
import java.lang.*;
import java.util.*;
import java.io.*;
import classes.*;
import file.*;

public interface AccountOperations
{
	void insertAccount(Account a);
	void removeAccount(Account a);
	Account getAccount(int accountNumber);
	void showAllAccounts();
}