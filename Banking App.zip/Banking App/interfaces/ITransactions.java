package interfaces;
import java.lang.*;
import java.util.*;
import java.io.*;
import classes.*;
import file.*;

public interface ITransactions
{
	void withdraw(double amount);
	void deposit(double amount);
}