package interfaces;
import java.lang.*;
import java.util.*;
import java.io.*;
import classes.*;
import file.*;

public interface CustomerOperations
{
	void setCustomer(Customer c);
	Customer getCustomer(int nid);
	void insertCustomer(Customer c);
	void removeCustomer(Customer c);
	void showAllCustomers();
}