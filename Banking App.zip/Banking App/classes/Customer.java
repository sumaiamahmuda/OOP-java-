package classes;
import java.lang.*;
import java.util.*;
import java.io.*;
import interfaces.*;
import file.*;

public class Customer implements AccountOperations
{
	private String name;
	private int nid;
	private Account accounts[] = new Account [100];


	public void setName(String name)
	{
		this.name = name;
	}

	public void setNid(int nid)
	{
		this.nid = nid;
	}


	public String getName()
	{
		return name;
	}

	public int getNid()
	{
		return nid;
	}

	public void insertAccount(Account a)
	{
		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i] == null)
			{
				accounts[i] = a;
				System.out.println();
				System.out.println("Account Inserted Successfully!");
				break;
			}
		}
	}

	public void removeAccount(Account a)
	{
		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i] == a)
			{
				accounts[i] = null;
				System.out.println();
				System.out.println("Account Removed Successfully!");
				break;
			}
		}
	}

	public void showAllAccounts()
	{
		for(Account a : accounts)
		{
			if(a != null)
			{
				a.showInfo();
			}
		}
	}

	public Account getAccount(int accountNumber)
	{
		Account a = null;

		for(int i=0; i<accounts.length; i++)
		{
			if(accounts[i] != null)
			{
				if(accounts[i].getAccountNumber() == accountNumber)
				{
					a = accounts[i];
					break;
				}
			}
		}
		return a;
	}
}