package classes;
import java.lang.*;
import java.util.*;
import java.io.*;
import interfaces.*;
import file.*;

public class Bank implements CustomerOperations, EmployeeOperations
{
	private Customer customers[] = new Customer[100];
	private Employee employees[] = new Employee[100];

	//EmployeeOperations
	public void setEmployees(Employee e)
	{

	}

	public void insertEmployee(Employee e)
	{

		for(int i=0; i<employees.length; i++)
		{
			if(employees[i] == null)
			{
				employees[i] = e;
				System.out.println();
				System.out.println("Employee Inserted Successfully!");
				break;
			}
		}

	}

	public void removeEmployee(Employee c)
	{

		for(int i=0; i<employees.length; i++)
		{
			if(employees[i] == c)
			{
				employees[i] = null;
				System.out.println();
				System.out.println("Employee Removed Successfully!");
				break;
			}
		}

	}

	public void showAllEmployees()
	{
		for(Employee e : employees)
		{
			if(e != null){
				System.out.println("Employee Name: "+ e.getName());
				System.out.println("Employee Id: "+ e.getEmpId());
				System.out.println("Employee Salary: "+ e.getSalary());
				System.out.println();
			}
		}

		System.out.println();
	}

	public Employee getEmployee(String empId)
	{
		Employee e = null;

		for(int i=0; i<employees.length; i++)
		{
			if(employees[i] != null)
			{
				if(employees[i].getEmpId().equals(empId))
				{
					e = employees[i];
					break;
				}
			}
		}
		return e;
	}

	//CustomerOperations
	public void setCustomer(Customer c)
	{

	}

	public void insertCustomer(Customer c)
	{

		for(int i=0; i<customers.length; i++)
		{
			if(customers[i] == null)
			{
				customers[i] = c;
				System.out.println();
				System.out.println("Customer Inserted Successfully!");
				break;
			}
		}

	}

	public void removeCustomer(Customer c)
	{

		for(int i=0; i<customers.length; i++)
		{
			if(customers[i] == c)
			{
				customers[i] = null;
				System.out.println();
				System.out.println("Customer Removed Successfully!");
				break;
			}
		}

	}

	public void showAllCustomers()
	{
		for(Customer c : customers)
		{
			if(c != null)
			{
				System.out.println("Customer Name: "+ c.getName());
				System.out.println("Customer Nid: "+ c.getNid());
				c.showAllAccounts();
				System.out.println();
			}
		}
	}

	public Customer getCustomer(int nid)
	{
		Customer c = null;

		for(int i=0; i<customers.length; i++)
		{
			if(customers[i] != null)
			{
				if(customers[i].getNid() == nid)
				{
					c = customers[i];
					break;
				}
			}
		}
		return c;
	}

}