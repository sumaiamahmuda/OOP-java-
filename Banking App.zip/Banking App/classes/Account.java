package classes;
import java.lang.*;
import java.util.*;
import java.io.*;
import interfaces.*;
import file.*;

public class Account implements ITransactions
{
	private int accountNumber;
	private double balance;

	public void setAccountNumber(int accountNumber)
	{
		this.accountNumber = accountNumber;
	}

	public void setBalance(double balance)
	{
		this.balance = balance;
	}

	public int getAccountNumber()
	{
		return accountNumber;
	}

	public double getBalance()
	{
		return balance;
	}

	public void showInfo()
	{
		System.out.println("Account Number: "+getAccountNumber());
		System.out.println("Account Balance: "+getBalance());
	}

	public void deposit(double amount)
	{
			System.out.println();
			System.out.println("Deposited Amount: "+ amount);
			balance = balance+amount;
			System.out.println("Current Balance: "+ balance);
	}
	
	public void withdraw(double amount)
	{
			System.out.println();
			System.out.println("Withdrawn Amount: "+ amount);
			balance = balance-amount;
			System.out.println("Current Balance: "+ balance);		
	}

}